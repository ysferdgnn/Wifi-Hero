﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
namespace Wifi_Hero_3_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int kilitdurum = 0;
        public static void wifiac()
        {
            Process process = new Process();
            ProcessStartInfo stratinfo = new ProcessStartInfo();
            stratinfo.WindowStyle = ProcessWindowStyle.Hidden;
            stratinfo.FileName = "cmd.exe";
            stratinfo.Arguments = "/C netsh wlan start hostednetwork";
            process.StartInfo = stratinfo;
            process.Start();
        }
        public static void wifikapat()
        {
            Process process = new Process();
            ProcessStartInfo stratinfo = new ProcessStartInfo();
            stratinfo.WindowStyle = ProcessWindowStyle.Hidden;
            stratinfo.FileName = "cmd.exe";
            stratinfo.Arguments = "/C netsh wlan stop hostednetwork";
            process.StartInfo = stratinfo;
            process.Start();
        }
        public static void degistir(string ssid, string key)
        {
            Process process = new Process();
            ProcessStartInfo stratinfo = new ProcessStartInfo();
            stratinfo.WindowStyle = ProcessWindowStyle.Normal;
            stratinfo.FileName = "cmd.exe";
            stratinfo.Arguments = "/C netsh wlan set hostednetwork mode=allow ssid=" + ssid + " key=" + key;
            process.StartInfo = stratinfo;
            process.Start();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (kilitdurum == 0)
            {
                button2.Enabled = true;
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                kilitdurum = 1;
            }
            else if (kilitdurum == 1)
            {
                button2.Enabled = false;
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                kilitdurum = 0;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            wifikapat();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!=""&&textBox2.Text!="")
            {
                try
                {
                    degistir(textBox1.Text, textBox2.Text);
                    MessageBox.Show("wifi bilgileri değiştirildi");
                }
                catch (Exception)
                {
                    MessageBox.Show("ERROR");
                }
            }
            else
            {
                MessageBox.Show("Lütfen gerekli alanları doldurun!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            wifiac();
            pictureBox1.Image = Properties.Resources.opened;
            MessageBox.Show("Wifi açıldı");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            wifikapat();
            pictureBox1.Image = Properties.Resources.closed;
            MessageBox.Show("Wifi kapandı");
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            wifikapat();
        }
    }
}
